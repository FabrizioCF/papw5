delimiter ###
create or replace function FN_VerificaUsuario (p_correo varchar (50), p_contra varchar(50))
	returns int
begin
	declare id int;
    
		select idUsuario into id
		from usuario
        where correo = p_correo
        and contrasena = p_contra;
        
	return id;
end; ###
delimiter ;

delimiter ###
create or replace function FN_ValidaArticuloComprado (p_idUsuario int, p_idArticulo int)
	returns int
begin
	declare comprado int;
    
		select idCompra into comprado
        from comprafinal
        where idUsuario = p_idUsuario
        and idArticulo = p_idArticulo;
        
        if (ifnull(comprado, 0) = 0) then return 0;
        elseif (ifnull(comprado, 0) > 0 ) then return 1;
        end if;
end; ###
delimiter ;