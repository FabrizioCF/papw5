create schema if not exists axiom;

use axiom;

create table if not exists
Rol(
		idRol			int not null auto_increment,
        nombreRol		varchar(50) not null,
        descripcion		varchar(255),
        activo			tinyint default 1,
        
        primary key (idRol)
);

create table if not exists
Usuario(
		idUsuario		int not null auto_increment,
		nombreUsuario	varchar(50)  not null,
        apellidoUsuario	varchar(50)  not null,
        correo			varchar(30) not null unique,
        contrasena		varchar(50) not null,
        imagenPerfil	mediumblob not null,
        direccion 		varchar(200),
        telefono 		varchar(10),
        idRol			int,
        activo			tinyint default 1,
        
        
        foreign key (idRol) references Rol(idRol),
        primary key (idUsuario)
);

create table if not exists
Articulo(
		idArticulo 		int not null auto_increment,
		nombreArticulo 	varchar(50) not null,
        descripcion		text not null,
        unidades		int,
        valoracion		double,
        publicado		TINYINT default 0,
        activo			TINYINT default 1,
        fechaPublica	timestamp,
        idUsuario		int not null,
        caracteristicas text,
        especificaciones text,
        
        foreign key (idUsuario) references Usuario(idUsuario),
        primary key (idArticulo)
);

create table if not exists
Categoria(
		idCategoria 	int not null auto_increment,
		nombreCat		varchar(50) not null,
        descripcion		varchar(250),
        orden			int,
        activo			tinyint default 1,
        
		primary key (idCategoria)
);

create table if not exists
FormaPago(
		idFormaPago		int not null auto_increment,
        nombre			varchar(100),
        descripcion		varchar(255),
         
        primary key (idFormaPago)
);

create table if not exists -- tabla de estatus puede servir para mensajes y para compras
Estatus(
		idEstatus		int not null auto_increment,
        nombreEstatus	varchar(50),
        descripcion		varchar(255),
        activo			tinyint default 1,
        
        primary key (idEstatus)
);

create table if not exists
CompraFinal(
		idCompra		int not null auto_increment,
        idUsuario		int not null,
        idArticulo		int not null,
        cantidad 		int,
		precioUnitario	double not null,
        idFormaPago		int,
        idEstatus		int,
        fechaCompra		timestamp,
        
        primary key (idCompra),
        foreign key (idUsuario) references Usuario(idUsuario),
        foreign key (idArticulo) references Articulo(idArticulo),
		foreign key (idEstatus) references Estatus(idEstatus),
        foreign key (idFormaPago) references FormaPago(idFormaPago)
);

create table if not exists
Carrito(
		 idCarrito		int not null auto_increment,
		 idUsuario	 	int not null,
		 idArticulo		int not null,
         cantidad 		int,
         
         foreign key (idUsuario) references Usuario(idUsuario),
         foreign key (idArticulo) references Articulo(idArticulo),
         primary key (idCarrito)
);

create table if not exists
ComentaArticulo(
		 idComentario	int not null auto_increment,
		 idUsuario	 	int not null,
		 idArticulo		int not null,
         titulo 		varchar(100) not null,
         cuerpo			text not null,
         fechaComent	timestamp,
         valoracion		int,
         
         foreign key (idUsuario) references Usuario(idUsuario),
         foreign key (idArticulo) references Articulo(idArticulo),
         primary key (idComentario)
);

create table if not exists
ArtiCat(
		idArtiCat		int not null auto_increment,
		idCategoria 	int not null,
		idArticulo		int not null,
         
        foreign key (idCategoria) references Categoria(idCategoria),
        foreign key (idArticulo) references Articulo(idArticulo),
        primary key (idArtiCat)
);

create table if not exists
Chat(
		idChat			int not null auto_increment,
        idCompra		int,
        idUsuario		int not null,
        idEstatus		int,
        
        primary key (idChat),
        foreign key (idCompra) references CompraFinal(idCompra),
        foreign key (idUsuario) references Usuario(idUsuario),
        foreign key (idEstatus) references Estatus(idEstatus)
);

create table if not exists
Mensaje(
		idMensaje		int not null auto_increment,
        idChat			int not null,
        remitente		int not null,
        destinatario	int not null,
        idEstatus		int not null,
        texto			text,
        fechaEnvio		timestamp,
        
        primary key (idMensaje),
        foreign key (idChat) references Chat(idChat),
        foreign key (remitente) references Usuario(idUsuario),
        foreign key (destinatario) references Usuario(idUsuario),
        foreign key (idEstatus) references Estatus(idEstatus)
);

create table if not exists
Galeria(
		idGaleria		int not null auto_increment,
        idArticulo		int not null,
        nombre			varchar(80),
        imagen			mediumblob not null,
        tipoImg			varchar(10),
        esVideo			tinyint default 0,
        rutaVideo		varchar(255),
        
        primary key (idGaleria),
        foreign key (idArticulo) references Articulo(idArticulo)
);