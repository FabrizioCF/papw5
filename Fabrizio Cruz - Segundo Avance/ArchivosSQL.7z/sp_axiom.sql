use axiom;

delimiter ###
create or replace procedure SP_InfoUsuario(IN p_idUsuario int)
begin 
	SELECT 	nombreUsuario, apellidoUsuario, correo, contrasena,
			direccion, telefono
	FROM Usuario
    WHERE idUsuario = p_idUsuario;
end ###
delimiter ;

delimiter ###
create or replace procedure  SP_ArticulosPorCategoria( IN p_idCat int, IN p_idUsuario int )
begin 
	SELECT ar.idArticulo, ar.nombreArticulo, ar.descripcion, valoracion, caracteristicas, especificaciones
    FROM Articulo ar inner join ArtiCat ac on ar.idArticulo = ac.idArticulo
    WHERE ac.idCategoria = p_idCAt
    AND ar.idUsuario != p_idUsuario
    AND ar.activo = 1 AND ar.publicado = 1;
end ###
delimiter ;

delimiter ###
create or replace procedure SP_AltaArtiCat(IN p_idArticulo int, IN p_idCategoria int)
begin 
	INSERT INTO ArtiCat (idCategoria, idArticulo)
    SELECT idCategoria, idArticulo
    FROM Articulo, Categoria
    WHERE idArticulo = p_idArticulo AND idCategoria = p_idCategoria;
end ###
delimiter ;

delimiter ###
create or replace procedure SP_AltaArticulo(
IN p_nombreArticulo varchar(50), IN p_descripcion text, IN p_unidades int, IN p_img1 mediumblob, IN p_valoracion double, IN p_visitas int,
IN p_idUsuario int, IN p_caracteristicas text, IN p_especificaciones text	)
begin 
	INSERT INTO Articulo
				(nombreArticulo, descripcion, unidades, img1, valoracion, visitas, idUsuario, caracteristicas, especificaciones)
			VALUES
				(p_nombreArticulo, p_descripcion, p_unidades, p_img1, p_valoracion, p_visitas, p_idUsuario, p_caracteristicas, p_especificaciones);
                
	SELECT LAST_INSERT_ID() as idNuevo;
end ###
delimiter ;

delimiter ###
create or replace procedure SP_ARTNOPUBLI(in p_idUsuario int)
begin 
	SELECT idArticulo, nombreArticulo, unidades
    FROM articulo
    WHERE idUsuario = p_idUsuario
		and publicado = 0;
end ###
delimiter ;

delimiter ###
create or replace procedure SP_PublicaArticulo(IN p_idArticulo int)
begin 
	UPDATE Articulo 
    SET publicado = 1
	WHERE idArticulo = p_idArticulo;
end ###
delimiter ;

delimiter ###
create or replace procedure SP_ARTSIPUBLI(IN p_idUsuario int)
begin 
	SELECT idArticulo, nombreArticulo, unidades
    FROM Articulo
    WHERE idUsuario = p_idUsuario
		and publicado = 1;
end ###
delimiter ;

delimiter ###
create or replace procedure SP_ConsArticulo(IN p_idArticulo int)
begin 
	SELECT nombreArticulo, descripcion, unidades, valoracion, caracteristicas, especificaciones
	FROM Articulo
	WHERE idArticulo = p_idArticulo;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_AgregaCarrito(IN p_idUsuario int, IN p_idArticulo int, IN p_cantidad int)
begin
	insert into Carrito
			(idUsuario, idArticulo, cantidad)
		Values 
			(p_idUsuario, p_idArticulo, p_cantidad);
            
	update Articulo 
		set unidades = (unidades - p_cantidad)
        where idArticulo = p_idArticulo;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_ConsultaCarrito(IN p_idUsuario int)
begin
	SELECT c.idArticulo, nombreArticulo, cantidad, unidades
    FROM Carrito c
		INNER JOIN Articulo a on c.idArticulo = a.idArticulo
		INNER JOIN Usuario u on c.idUsuario = u.idUsuario
    WHERE c.idUsuario = p_idUsuario;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_ActualizaCarrito(IN p_idUsuario int, IN p_idArticulo int, IN p_cantidad int)
begin

	DECLARE tmpCantidad int;

	SELECT tmpCantidad = cantidad
		FROM Carrito
			WHERE 	idUsuario = p_idUsuario
			AND		idArticulo = p_idArticulo; 
		
	UPDATE Articulo 
	SET unidades = (unidades + tmpCantidad)
	WHERE idArticulo = p_idArticulo;
        
		
        UPDATE Articulo 
		SET unidades = (unidades - p_cantidad)
        WHERE idArticulo = p_idArticulo;
        
		UPDATE Carrito 
			SET cantidad = p_cantidad
            WHERE 	idUsuario = p_idUsuario
            AND		idArticulo = p_idArticulo;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_EliminaDelCarrito(IN p_idUsuario int, IN p_idArticulo int)
begin
	delete from Carrito
    where idUsuario = p_idUsuario
    and idArticulo = p_idArticulo;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_ConsultaComentarios(IN p_idArticulo int)
begin
	
    select correo, nombreArticulo, titulo, cuerpo, fechaComent, valoracion
    from ComentaArticulo
    where idArticulo = p_idArticulo;
    
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_ConsultaThumbnail(IN p_idArticulo int)
begin
	select img1 
    from articulo 
    where idArticulo = p_idArticulo;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_AltaGaleria(IN p_idArticulo int, IN p_nombre varchar(255), IN p_img mediumblob, IN p_tipoImg varchar(10), IN p_esVideo tinyint, IN p_rutaVid varchar(255))
begin
	insert into galeria
			(idArticulo, nombre, imagen, tipoImg, esVideo, rutaVideo)
		values
			(p_idArticulo, p_nombre, p_img, p_tipoImg, p_esVideo, p_rutaVid);
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_ConsultaImgGaleria(IN p_idArticulo int, IN p_nombreImg varchar(255))
begin
	select imagen 
    from galeria 
    where idArticulo = p_idArticulo
	and nombre = p_nombreImg;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_ConsultaVidGaleria(IN p_idArticulo int)
begin
	select rutaVideo, nombre 
    from galeria 
    where idArticulo = p_idArticulo
    and esVideo = 1;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_ConsultaImgUsuario(IN p_idUsuario int)
begin
	select imagenPerfil 
    from usuario 
    where p_idUsuario = p_idUsuario;
end; ###
delimiter ;

delimiter ###
create or replace procedure SP_CreaCompra(in p_idUsuario int, in p_idArticulo int, in p_cantid int, in p_precio double)
begin
	insert into comprafinal
		(idUsuario, idArticulo, cantidad, precioUnitario, fechaCompra)
        values
        (p_idUsuario, p_idArticulo, p_cantid, p_precio, CURDATE());
        
        delete from carrito
			where idUsuario = p_idUsuario;
end; ###
delimiter ;

articatdelimiter ###
create or replace procedure SP_ConsultaCompra(in p_idUsuario int)
begin
	select idCompra, cf.idUsuario, cf.idArticulo, cantidad, precioUnitario, idEstatus, fechaCompra, ar.nombreArticulo
    from comprafinal cf inner join articulo ar 
		on cf.idArticulo = ar.idArticulo
    where cf.idUsuario = p_idUsuario;
end; ###
delimiter ;




























































